const reasonInput = document.querySelector('#input-reason')
const amountInput = document.querySelector('#input-amount')
const confirmBtn = document.querySelector('#confirmBtn')
const cancelBtn = document.querySelector('#cancelBtn')
const expensesList = document.querySelector("#expenses-list")
const expensesOutput = document.querySelector('#total-expenses');

let totalExpenses = 0;


function clearInput(){
    amountInput.value="";
    reasonInput.value="";
}

confirmBtn.addEventListener('click', () => {
    //console.log("Expense Added!");
    const enteredReason = reasonInput.value;
    const enteredAmount = amountInput.value;
    if (enteredReason.trim().length <= 0 || enteredAmount <= 0 || enteredAmount.trim().length <= 0) {
        console.log("Enter valid inputs")

    } else {
        console.log("Expense Added!");
        console.log(enteredAmount, " | ", enteredReason)
        const newItem = document.createElement('ion-item');
        newItem.textContent=enteredReason+" : Rs."+enteredAmount+"/-";
        expensesList.appendChild(newItem);

        totalExpenses += +enteredAmount;
        expensesOutput.textContent="Rs."+totalExpenses+"/-";
        clearInput();

    }
})

cancelBtn.addEventListener('click', clearInput);

